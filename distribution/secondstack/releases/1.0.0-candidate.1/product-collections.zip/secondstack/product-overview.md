# SecondStack Product Knowledge

Knowledge export: 1.0.0-candidate.1. This is a dated reference summary, not a claim of
current feature execution. Retain the original review dates and evidence limits.
Read official topic sources before factual scripts. Source documents may be stale;
resolve material gaps and conflicts before production.

# SecondStack — product source registry

Reviewed 2026-11-03. Output language: `en`.

Self-hosted enterprise AI platform. The documentation index was read for discovery only; read relevant feature pages and conditions before claims.

## Evidence boundaries

Only the documentation entry page was read, not topic-specific feature pages or live product UI. Its displayed last-updated date was July 7, 2026. No private DESIGN.md was fetched. Do not generalize deployment, privacy, pricing or model availability from the index.

The machine-readable Source Registry document records what was actually read.
The brandkit [S01] governs presentation, not feature truth. Read current official
topic documentation and prerequisites before script; record URLs, sections,
claims, scope, omissions and conflicts in episode-local `RESEARCH.md`. If essential
evidence is missing, stop before script and ask for the official source. Never
borrow LakeSentry claims, UI, sample numbers or product credentials.

## Optional scheduler [S02]

https://content-machine.spot.t1a.dev/2s/

Read only relevant material, not the entire board. Access redirected to sign in
in the Project Assistant session on 2026-11-03; no posts were read. Video Producer
access is untested. Optional unavailability does not block adequately evidenced
research. Do not copy cookies or request raw credentials. No scheduler writes.
Record minimal observed provenance only; do not bulk-copy private content into shared resources.
Post approval is not script approval; a schedule does not prove publication.
