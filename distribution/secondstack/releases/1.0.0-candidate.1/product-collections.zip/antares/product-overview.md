# Antares Product Knowledge

Knowledge export: 1.0.0-candidate.1. This is a dated reference summary, not a claim of
current feature execution. Retain the original review dates and evidence limits.
Read official topic sources before factual scripts. Source documents may be stale;
resolve material gaps and conflicts before production.

# Antares — product source registry

Reviewed 2026-11-03. Output language: `en`.

BI migration tool; analysis and conversion. This category is recorded from the brand rules, not verified feature execution.

## Evidence boundaries

The website includes effort and savings percentages that conflict with the brand rules. Preserve this conflict; omit percentages and ask the product owner before any claim that depends on them. No documentation root was found in the observed homepage links; obtain current official topic documentation before technical scripts.

The machine-readable Source Registry document records what was actually read.
The brandkit [S01] governs presentation, not feature truth. Read current official
topic documentation and prerequisites before script; record URLs, sections,
claims, scope, omissions and conflicts in episode-local `RESEARCH.md`. If essential
evidence is missing, stop before script and ask for the official source. Never
borrow LakeSentry claims, UI, sample numbers or product credentials.

## Optional scheduler [S02]

https://content-machine.spot.t1a.dev/ant/

Read only relevant material, not the entire board. Access redirected to sign in
in the Project Assistant session on 2026-11-03; no posts were read. Video Producer
access is untested. Optional unavailability does not block adequately evidenced
research. Do not copy cookies or request raw credentials. No scheduler writes.
Record minimal observed provenance only; do not bulk-copy private content into shared resources.
Post approval is not script approval; a schedule does not prove publication.
