# Editorial templates
Use only the two universal layouts through prepare_page.py. Supply approved JSON;
examples are synthetic layout fixtures, not product facts. Read the skill research
reference and the selected product Collection. Fixed historical demos and covers
are not included. New scene types require separately prepared trusted templates;
these layouts are not an arbitrary storyboard generator.
