# LakeSentry visual rules

Use the current official brandkit: https://lakesentry.io/brandkit/ . The installed
brand.json supplies build colors, font faces and logo paths. Use Outfit headings,
Plus Jakarta Sans body/UI, and a system mono stack for code. Use original supplied
logos with clear space; do not redraw, recolor or retype the lockup. Prefer light,
calm technical layouts. No neon, glow, gradient text or panic imagery. Review actual
frames at phone size. Platform geometry comes from runtime/formats/shorts/.

Universal templates are editorial cards, not verified product UI. Keep disclosures.
Real walkthroughs need authorized dated capture and approved scripts. Do not infer
product features, prices or savings from an illustration. No background music by
default; sound effects require a suitable approved plan and license checks. Voice
is an explicit intake choice. Historical per-video style experiments are not current
production requirements. Review actual speech, captions and final media.

Assets retain their source/license records under assets/. Historical extra font and
sound files may be present; presence is not permission to override current styling.
